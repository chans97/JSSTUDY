'use strict';
/*const row = 5;
const col = 5;
const rowList = [1, 2, 3, 4, 5];
const colList = [1, 2, 3, 4, 5];
*/

const range = (start, end) => {
    let array = [];
    for (let i = start; i < end + 1; ++i) {
        array.push(i);
    }
    return array;
}

const row = 10;
const col = 10;
const bombNumber = 10

const rowList = range(1, row);
const colList = range(1, col);
const bombList = range(0, bombNumber - 1);
//const bombList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];

const make_Game = (parent) => {
    makeSection(parent);

    let totallist = ramdomBombList();
    let bombListi = totallist[0];
    let bombListj = totallist[1];

    setBomb(bombListi, bombListj);
    setNumber();
    showNumber();
    pickBomb();
    document.body.addEventListener("auxclick", checkRightBombNumber); //for success
    document.body.addEventListener("click", checkLastBombNumber); //for success
    parseZero(); //0 누를 시 확장
    parseBomb(); //for fail 폭탄 선택시

}

const parseBomb = () => {
    let bomblen = document.getElementsByName("10").length;
    let bombList = range(0, bomblen - 1);
    bombList.forEach((bombbutton) => {
        let but = document.getElementsByName("10")[bombbutton];
        but.addEventListener("click", (e) => {
            alert("Fail!!\n바보");
            let header = document.querySelector("div");
            header.parentNode.removeChild(header);
            make_Game(document.body);
        });
    })
}

const parseZero = () => {
    let zerolen = document.getElementsByName("0").length;
    let zeroList = range(0, zerolen - 1);
    zeroList.forEach((zerobutton) => {
        let but = document.getElementsByName("0")[zerobutton];
        but.addEventListener("click", extendZero);
    })
}

const extendZero = (event) => {

    if (event.path != undefined) {
        let zeroarray = event.path[0].id.split(",")
        var i = Number(zeroarray[0]);
        var j = Number(zeroarray[1]);
    }
    else {
        let zeroarray = event.id.split(",")
        var i = Number(zeroarray[0]);
        var j = Number(zeroarray[1]);

    }

    let point1 = document.getElementById([i - 1, j - 1]);
    let point2 = document.getElementById([i - 1, j]);
    let point3 = document.getElementById([i - 1, j + 1]);
    let point4 = document.getElementById([i, j - 1]);
    let point5 = document.getElementById([i, j + 1]);
    let point6 = document.getElementById([i + 1, j - 1]);
    let point7 = document.getElementById([i + 1, j]);
    let point8 = document.getElementById([i + 1, j + 1]);
    let pointList = [point1, point2, point3, point4, point5, point6, point7, point8];

    pointList.forEach((point) => {
        if (point != null) {
            if (point.name == "0" && point.innerHTML == "") {
                point.innerHTML = "*";
                extendZero(point);
            }
            else if (point.name != "0") {
                point.innerHTML = point.name;
            }
        }
    })
}

const makeSection = (parent) => {

    let sectionRow = rowList;
    let topdiv = elt("div", { class: "topdiv" })
    sectionRow.forEach((i) => {
        let sectionCol = colList;
        let firstlist = [];
        sectionCol.forEach((j) => {
            let abutton = makeA_Button(i, j);
            firstlist.push(abutton);
        })
        topdiv.appendChild(eltbomb("div", { oncontextmenu: "return false" }, firstlist));
    })
    parent.appendChild(topdiv);
}

const makeA_Button = (i, j) => {
    let point = [i, j];
    let abutton = elt("button", { id: point, class: "button" },)//document.createElement("button")
    return abutton;
}

const setBomb = (bombListi, bombListj) => {
    bombList.forEach((i) => {
        makeA_Bomb(bombListi[i], bombListj[i])
    })
}

const makeA_Bomb = (i, j) => {
    let bomb = document.getElementById([i, j]);
    bomb.name = 10;
    //bomb.classList.add("bomb");
}

/*random bomb 설치 방법, 1~100까지 랜덤으로 10개 뽑아,
그 이후에 앞주리수=i, 뒷자리수=j, 할당하고 나온좌표 10개 리스트로 반환*/
const ramdomBombList = () => {
    const numOfbomb = bombNumber

    let bombListi = []
    let bombListj = []
    let totallist = []

    //list = rowList;
    while (bombListi.length != numOfbomb) {
        let randomnumber = getRandomInt(0, row * col);
        if (!totallist.includes(randomnumber)) {
            let i = randomnumber / col;
            i = Math.floor(i);
            let j = randomnumber - col * i + 1;
            ++i;
            totallist.push(randomnumber);
            bombListi.push(i);
            bombListj.push(j);
        }
    };

    //console.log(bombListi, bombListj);
    let returnlist = [bombListi, bombListj];
    return returnlist;
}

const getRandomInt = (min, max) => {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min; //최댓값은 제외, 최솟값은 포함
}

const rollAllButton = (func) => {
    rowList.forEach((i) => {
        colList.forEach((j) => {
            func(i, j);
        }
        )
    })
}

const setNumber = () => {
    rollAllButton(set_AbuttonNumber);
}

const set_AbuttonNumber = (i, j) => {
    let count = 0;
    let point1 = document.getElementById([i - 1, j - 1]);
    let point2 = document.getElementById([i - 1, j]);
    let point3 = document.getElementById([i - 1, j + 1]);
    let point4 = document.getElementById([i, j - 1]);
    let point5 = document.getElementById([i, j + 1]);
    let point6 = document.getElementById([i + 1, j - 1]);
    let point7 = document.getElementById([i + 1, j]);
    let point8 = document.getElementById([i + 1, j + 1]);
    let pointList = [point1, point2, point3, point4, point5, point6, point7, point8];

    pointList.forEach((point) => {
        if (document.getElementById([i, j]).name != "10") {//v폭탄이 아닐 경우만 
            if (point != null) {
                if (point.name == "10") {
                    count++;
                }
            }
            document.getElementById([i, j]).name = count;
        }
    })

}

const showNumber = () => {
    rollAllButton(show_ANumber);
}

const show_ANumber = (i, j) => {
    let point = document.getElementById([i, j]);
    point.addEventListener("click", () => {
        if (point.name == "0") {
            point.innerHTML = "*";
        }
        else {

            point.innerHTML = point.name;
        }
    })
}

const pickBomb = () => {
    rollAllButton(pick_ABomb);
}

const pick_ABomb = (i, j) => {
    let point = document.getElementById([i, j]);
    point.addEventListener("auxclick", () => {
        if (point.value != "picked") {
            point.innerHTML = "💣";
            point.value = "picked";
        }
        else {
            point.innerHTML = "";
            point.value = "";
        }

    })
}

const checkLastBombNumber = () => {
    let rightBombCount = 0;
    rowList.forEach((i) => {
        colList.forEach((j) => {
            rightBombCount = rightBombCount + check_ARightBombNumber(i, j);
        }
        )
    })
    let emptyCount = 0;
    rowList.forEach((i) => {
        colList.forEach((j) => {
            emptyCount = emptyCount + check_AEmptyNumber(i, j);
        }
        )
    })
    let lastBombNumber = bombNumber - rightBombCount;
    if (lastBombNumber == emptyCount) {
        alert("Finish!!!!!!!!!!!!!!!!!\c천재");
        let header = document.querySelector("div");
        header.parentNode.removeChild(header);
        make_Game(document.body);
    }
}

const checkRightBombNumber = () => {
    let count = 0;
    rowList.forEach((i) => {
        colList.forEach((j) => {
            count = count + check_ARightBombNumber(i, j);
        }
        )
    })
    if (count == bombNumber) {
        alert("Finish!!!!!!!!!!!!!!!!!\n축하드려용");
        let header = document.querySelector("div");
        header.parentNode.removeChild(header);
        make_Game(document.body);
    }
}

const check_AEmptyNumber = (i, j) => {
    let point = document.getElementById([i, j]);
    if (point.innerHTML == "") {
        return 1;
    }
    return 0;
}

const check_ARightBombNumber = (i, j) => {
    let point = document.getElementById([i, j]);
    if (point.value == "picked" && point.name == "10") {
        return 1;
    }
    return 0;
}